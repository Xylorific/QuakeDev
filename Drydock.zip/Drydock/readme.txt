Copy and paste the files from "maps" in this zip to "QuakeDev > id1 > maps"

Bring the "gfx" folder from this zip to "QuakeDev > id1". Do not extract the files
out from the "gfx" folder.